MSI strongly recommends to update the BIOS & ME via M-Flash as an ME update is required for this bios release or
you can update the BIOS via live update under windows.